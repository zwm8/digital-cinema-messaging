USE [AMS]
GO

/****** Object:  StoredProcedure [dbo].[flm_GetNonCriticalFacilityInfo]    Script Date: 12/04/2009 16:46:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








CREATE PROCEDURE [dbo].[flm_GetNonCriticalFacilityInfo]
(
	@Site_Id int
)
AS

SELECT     Exhibitor.Exhibitor_Name, 
			Site.Street_1,
			Site.Street_2, 
			Site.Street_3, 
			Site.State, 
			Site.City, 
			Site.Zip_Code, 
			Site.Nation, 
			Site.Site_Name, 
			Site.Site_Id,
			Site.Time_Zone,
			(SELECT     Count(*)
			 FROM         Auditorium INNER JOIN
								  Location ON Auditorium.Location_Id = Location.Location_Id INNER JOIN
								  Site ON Location.Site_Id = Site.Site_Id
			 WHERE     (Site.Site_Id = @Site_Id)) as TotalScreenCount
FROM         Exhibitor INNER JOIN
                      Site ON Exhibitor.Exhibitor_Id = Site.Exhibitor_Id
WHERE     (Site.Site_Id = @Site_Id)


GO

