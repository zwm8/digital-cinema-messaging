﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Security.Cryptography.X509Certificates;
using System.Xml;
using System.IO;
using System.Xml.Serialization;

using DCIP.FLM;
using www.smpte.org.etm;

namespace FLM.ConsoleTestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            int siteId = 473;
            string certificateSerialNumber = "0EFB7EEBDCDA4F64A718DB3FF908B085";
            StoreLocation storeLocation = StoreLocation.CurrentUser;
            //string connectionString = "Data Source=SEMBERLEY;Initial Catalog=AMS.12.21.2009;Integrated Security=True";
            string connectionString = "Data Source=WEBSERVER;Initial Catalog=AMS;Integrated Security=True";

            DCinemaSecurityMessageType dCinemaSecurityMessage = FacilityListMessageUtilities.FLM_Create(siteId, certificateSerialNumber, storeLocation, connectionString);
            //XmlDocument xmlDocument = FacilityListMessageUtilities.FLM_Create(siteId, certificateSerialNumber, storeLocation, connectionString);
            //xmlDocument.Save(@"\Source_SMPTE\Output\SQL_FLM_ExtraTheatreMessage.xml");

            //XmlDocument xmlDocumentSigned = FacilityListMessageUtilities.FLM_Sign(xmlDocument, certificateSerialNumber, storeLocation);
            //xmlDocumentSigned.Save(@"\Source_SMPTE\Output\SQL_FLM_ExtraTheatreMessageSigned.xml");

            //XmlDocument xmlDocumentExtended = FacilityListMessageUtilities.FLMEXT_Create(siteId, certificateSerialNumber, storeLocation, connectionString);
            //xmlDocumentExtended.Save(@"\Source_SMPTE\Output\SQL_FLMEXT_ExtraTheatreMessage.xml");

        }
    }
}
